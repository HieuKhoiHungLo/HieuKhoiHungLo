-- Mock SQL Backup Content
SELECT current_timestamp;